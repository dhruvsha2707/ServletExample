package com.abc.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.abc.dbUtil.DBConnection;

/**
 * Servlet implementation class RelativeListServlet
 */
public class RelativeListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection con = null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd = null;
		
		try{
			HttpSession session = request.getSession(false);
			//String user = (String)session.getAttribute("username");
			//String username = user.toUpperCase();
	        
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			String SQL= "Select * from Relatives";
			ResultSet rs = stmt.executeQuery(SQL);
			pw.println("<table border=1 width=50% height=50%>");
            pw.println("<tr>< th>FirstName</th> <th>LastName</th> <th>Age</th> <th>Gender</th> <th>Phone</th> <th>Address</th> <th>Relationship</th> <th>Occupation</th> <th>Designation</th> <th>Save/Edit<</th> <th>Delete</th><tr>");
			if(rs != null){
				while(rs.next()){
					
				}
			}
			else{
				pw.print("No Relative Details Found");
			}
			
		}
		catch (Exception e) {
		}
	}
}
