package com.abc.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.abc.dbUtil.DBConnection;

/**
 * Servlet implementation class registerServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Connection con = null;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd=null;
		
		String username = request.getParameter("username");
		String userpass = request.getParameter("userpass");
		
		try{
			con = DBConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into login values(?,?)");
			
			ps.setString(1, username);
            ps.setString(2, userpass);
            
            int i = ps.executeUpdate();
            if (i > 0) {
            	System.out.println("You are successfully registered...");
            	rd = request.getRequestDispatcher("index.html");
            	rd.forward(request, response);
            }
            else{
            	pw.print("You are successfully registered...");
            	rd = request.getRequestDispatcher("views/register.html");
            	rd.include(request, response);
            }
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		finally{
			try {
				con.close();
				System.out.println("Connection is closed");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}