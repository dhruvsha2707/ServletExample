package com.abc.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.abc.dbUtil.DBConnection;

/**
 * Servlet implementation class loginAction
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection con = null;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd =null;
		String user = null;
		ResultSet rs = null;
		Statement stmt = null;
		
		String username = request.getParameter("username");
		String userpass = request.getParameter("userpass");
		
		try{
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String sql="select * from login where username='"+username+"' and password='"+userpass+"'";
			rs =stmt.executeQuery(sql);
			
			while(rs.next()) {
				user = rs.getString("username");
			}
			
			if(user!= null) {
				
				//create a session
				HttpSession session = request.getSession();
				Date createTime = new Date(session.getCreationTime());
				String sessionId = session.getId();
				Boolean isNew = session.isNew();
				session.setAttribute("username", user);
				
				System.out.println("Session Start-Time:"+createTime);
				System.out.println("Session Id:"+sessionId);
				System.out.println("Session Status:"+isNew);
				
				rd = request.getRequestDispatcher("views/welcome.html");
				rd.forward(request, response);
			}
			
			else{
				pw.println("Invalid Username/Password");
				rd = request.getRequestDispatcher("index.html");
				rd.include(request, response);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			try {
				
				//CleanUp Environment
				rs.close();
				stmt.close();
				con.close();
				System.out.println("Connection closed successfully");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		/*if(username.equals("admin") && userpass.equals("admin")){
			pw.println("Valid Username/Password");
			rd = request.getRequestDispatcher("views/welcome.html");
			rd.forward(request, response);
		}
		
		else {
			pw.println("Invalid Username/Password");
			rd = request.getRequestDispatcher("/index.html");
			rd.include(request, response);
		}*/
	}
}
