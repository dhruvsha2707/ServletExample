package com.abc.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.abc.dbUtil.DBConnection;

/**
 * Servlet implementation class createEmployeeServlet
 */
public class createEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private Connection con = null;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		RequestDispatcher rd = null;
		
		String fName= request.getParameter("emp_fname");
		String mName= request.getParameter("emp_mname");
		String lName= request.getParameter("emp_lname");
		String age= request.getParameter("emp_age");
		String address= request.getParameter("emp_add");
		String phone= request.getParameter("emp_pnum");
		String department= request.getParameter("emp_dept");
		String email= request.getParameter("emp_email");
		
		try{
			HttpSession session = request.getSession(false);
			String user = (String)session.getAttribute("username");
			String username = user.toUpperCase();
	        //pw.println("Hello "+username);
	        
			con = DBConnection.getConnection();
			String sql="insert into employee values(?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1, fName);
			ps.setString(2, mName);
			ps.setString(3, lName);
			ps.setString(4, age);
			ps.setString(5, address);
			ps.setString(6, phone);
			ps.setString(7, department);
			ps.setString(8, email);
			
			int i = ps.executeUpdate();
			if(i>0){
				pw.println("New User Created Successfully By "+username);
				rd = request.getRequestDispatcher("/views/newEmployee.html");
				rd.include(request, response);
			}
			else{
				pw.println("Try Again");
				rd = request.getRequestDispatcher("/views/newEmployee.html");
				rd.include(request, response);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				con.close();
				System.out.println("Connection closed successfully");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
