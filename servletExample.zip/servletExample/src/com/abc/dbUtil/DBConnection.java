package com.abc.dbUtil;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	
	private static Connection con;
 
	public static Connection getConnection() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			try{
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Servlet","root","root");
				System.out.println("Connection created successfully");
			}
			catch (Exception e) {
				System.out.println("Failed to create the database connection.");
			}
		}
		catch (Exception e) {
			System.out.println("Driver not found");
		}
		return con;
	}
}